<?php

//Create connection
$con=mysqli_connect("emotionable.ddns.net","carmenpui","carmenpui","ebdb",3306);

//Check connection
if(mysqli_connect_errno())
{
	echo "Failed to connect to MySQL: " . mysqli_connect_errno();
}


$Name = $_POST['Name'];
$Email = $_POST['Email'];
$SName = $_POST['SName'];

if(empty($Name) || empty($Email) || empty($SName))
{
	echo "Please do not leave * blank";
}
else
{
	mysqli_query($con, 'SET foreign_key_checks = 0');

	$sql = "INSERT INTO ebdb.Teacher(id, name, email, student_name) VALUES (NULL,'$Name','$Email', '$SName')";
	
	$sql2 = "INSERT INTO ebdb.Result(resultId, score, feedback, stud_name) VALUES (NULL, 0, NULL, '$SName')";
	
	$sql3 = "SELECT resultId FROM ebdb.Result WHERE stud_name = '$SName'";
	
	//retrive last result_id created
	//mysql_insert_id($con);
	
	
	if(!mysqli_query($con, $sql))
	{
		die('Error: ' . mysqli_error($con));
	}
	else if(!mysqli_query($con, $sql2))
	{
		die('Error: ' . mysqli_error($con));
	}
	else
	{
		echo "1 record added into Teacher database.";
		echo "1 record added into Result database.";
	}
	
	
	$result = mysqli_query($con,$sql3);
	$resultId;
	
	while($row = mysqli_fetch_array($result)) {
		//echo "<br>";
		
		$resultId = $row['resultId'];
		
  		//echo $resultId;
  		//echo "<br>";
	}
	
	$sql4 = "INSERT INTO ebdb.Student(studid, studname, result_id, teacher_name) VALUES (NULL,'$SName', '$resultId','$Name')";
	
	if(!mysqli_query($con, $sql4))
	{
		die('Error: ' . mysqli_error($con));
	}
	else
	{	
		echo "1 record added into Student database.";
	}
	
	mysqli_query($con, 'SET foreign_key_checks = 1');
}

mysqli_close($con);
?>