<?php
function Send_Mail($to,$subject,$body)
{
	require 'class.phpmailer.php';
	$from = "emotionable.team@gmail.com";
	$mail = new PHPMailer();
	$mail->IsSMTP(true); // SMTP
	$mail->SMTPAuth   = true;  // SMTP authentication
	$mail->Mailer = "smtp";
	$mail->Host= "tls://email-smtp.us-west-2.amazonaws.com"; // Amazon SES
	$mail->Port = 465;  // SMTP Port
	$mail->Username = "AKIAI6F5RKMWOUJTB7UQ";  // SMTP  Username
	$mail->Password = "Avgi0OoxAOZOvef8+4SHLWN4iDrh1hq/2cUGVIHtmYP3";  // SMTP Password
	$mail->SetFrom($from, 'Emotionable');
	$mail->AddReplyTo($from,'Emotionable');
	$mail->Subject = $subject;
	$mail->MsgHTML($body);
	$address = $to;
	$mail->AddAddress($address, $to);
	
	if(!$mail->Send()){
		echo("Failed to send");
		//return false;
	}
	else{
		echo("Email sent");
		//return true;
	}

}
?>