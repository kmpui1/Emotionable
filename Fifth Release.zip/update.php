<?php

	//Create connection
	$con=mysqli_connect("emotionable.ddns.net","carmenpui","carmenpui","ebdb",3306);
	
	//Check connection
	if(mysqli_connect_errno())
	{
		echo "Failed to connect to MySQL: " . mysqli_connect_errno();
	}
	
	$resultId;
	$Score = $_POST['Score'];
	$Feedback = $_POST['Feedback'];
	$SName = $_POST['SName'];
	
	$sql = "SELECT resultId FROM ebdb.Result WHERE stud_name = '$SName'";
	$result = mysqli_query($con,$sql);
	$resultId;
	
	while($row = mysqli_fetch_array($result)) {
		//echo "<br>";
		
		$resultId = $row['resultId'];
		
  		//echo $resultId;
  		//echo "<br>";
	}
	
	echo json_encode($resultId);

	if(empty($Score) || empty($Feedback) || empty($SName))
	{
		echo "Please do not leave * blank";
	}
	else
	{
		
		$sql = "UPDATE ebdb.Result SET score = '$Score', feedback = '$Feedback' WHERE resultId = $resultId";
		
		if(!mysqli_query($con, $sql))
		{
			die('Error: ' . mysqli_error($con));
		}
		
		echo "Result database was updated with score and feedback and it will be sent to the teacher's email.";
	
		
	}
	
	
	mysqli_close($con);
?>