<?php
	require 'sendMail.php';
	
	$Teacher = $_POST['Teacher'];
	$TeacherEmail = $_POST['TeacherEmail'];
	$Student = $_POST['Student'];
	$Score = $_POST['Score'];
	//$Feedback = $_POST['Feedback'];
	
	
	$to = $TeacherEmail;
	$subject = "Result Feedback";
	$body = "Hi ".$Teacher.",<br/>This is the result of the test your student just did.<br/><br/>Below are the feedback of the test: <br/><br/>Student Name: ".$Student."<br/>Score: ".$Score."<br/><br/><br/>Cheers,<br/>Emotionable Team"; // HTML  tags
	Send_Mail($to,$subject,$body);
 ?>